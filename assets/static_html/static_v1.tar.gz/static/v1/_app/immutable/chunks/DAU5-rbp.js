import{F as e,R as t,Z as n,m as r,t as i}from"./EEnsIFkr.js";var a=t(`<svg fill="none" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M20.25 6.375c0 2.278-3.694 4.125-8.25 4.125S3.75 8.653 3.75 6.375m16.5
        0c0-2.278-3.694-4.125-8.25-4.125S3.75 4.097 3.75 6.375m16.5 0v11.25c0 2.278-3.694
        4.125-8.25 4.125s-8.25-1.847-8.25-4.125V6.375m16.5 0v3.75m-16.5-3.75v3.75m16.5 0v3.75C20.25
        16.153 16.556 18 12 18s-8.25-1.847-8.25-4.125v-3.75m16.5 0c0 2.278-3.694 4.125-8.25
        4.125s-8.25-1.847-8.25-4.125"></path></svg>`);function o(t,o){let s=i(o,`opacity`,3,.9),c=i(o,`width`,3,`1.5rem`),l=i(o,`color`,3,`currentColor`);var u=a();r(u,`stroke-width`,2),n(()=>{r(u,`stroke`,l()),r(u,`width`,c()),r(u,`opacity`,s())}),e(t,u)}export{o as t};